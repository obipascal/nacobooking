Copyright © 2019 by BravoTeam <div class="f-visa"><img src="{{asset('icon/ico_paymethod.svg')}}" alt="payments" class="img-responsive"></div>
